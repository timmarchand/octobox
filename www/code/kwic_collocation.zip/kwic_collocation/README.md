# KWIC & Collocation (standalone)

Reproduces the **KWIC & Collocation** module: concordance lines for a search
term plus a collocation table.

## Run it
Open the `.Rproj`, install the listed packages, and source `kwic_collocation.R`.

## Things to try
- Change `search_term` (use `quanteda::phrase("sea shells")` for multi-word).
- Widen `window` for more context.
- Lower `min_count` to surface rarer collocations.
