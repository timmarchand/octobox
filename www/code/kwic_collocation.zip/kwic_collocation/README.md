# KWIC & Collocation (standalone)

Reproduces the **KWIC & Collocation** module: concordance lines for a search
term plus a collocation table.

## Run it
Open the `.Rproj`, install the listed packages, and source `kwic_collocation.R`.

It writes two files into the project folder:
`kwic_results.csv` (concordance lines) and `collocation_results.csv`.

## Worked example
With the bundled `sample_corpus.csv` and the defaults
(`search_term <- "the"`, `window <- 5L`):

1. The KWIC step prints the first 20 lines where *the* appears, with five
   words of context either side, and saves them to `kwic_results.csv`.
2. The collocation step lists the strongest two-word sequences in the corpus,
   scored by quanteda's collocation statistic, saved to
   `collocation_results.csv`.

To analyse a different word, edit one line and re-source:

```r
search_term <- "dog"
```

For a multi-word search, wrap it in `phrase()`:

```r
concordance <- quanteda::kwic(toks, pattern = quanteda::phrase("the dog"), window = 5L)
```

## How this differs from the Octobox app
**The script and the app compute *different* kinds of collocation - expect the
numbers to differ.**

- This script uses `quanteda.textstats::textstat_collocations()`, which scans
  the whole corpus for frequently recurring **multi-word sequences** (bigrams,
  trigrams) and scores them with a single lambda/z statistic. It is *not*
  anchored to your search term.
- The app computes **node-based windowed collocation**: it takes the collocates
  appearing in chosen positions around your search term (e.g. `left1`,
  `right1`) and scores each with four association measures - Mutual Information,
  t-score, log-likelihood, and logDice - using a corpus-token contingency
  model, with a count column per position.

So the app answers "which words are attracted to *this* node, and on which
side?", while the script answers "which word sequences recur across the corpus
as a whole?". Both are standard, but they are different analyses. The script
keeps to quanteda's built-in function so the method stays transparent and easy
to adapt; for the app's association-measure formulas see Gablasova, Brezina &
McEnery (2017).

## Things to try
- Change `search_term` (use `quanteda::phrase("sea shells")` for multi-word).
- Widen `window` for more context.
- Lower `min_count` to surface rarer collocations.
- Set `size = 3` in `textstat_collocations()` for three-word sequences.
