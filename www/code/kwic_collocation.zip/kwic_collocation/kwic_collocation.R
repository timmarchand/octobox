# =============================================================================
# KWIC & Collocation - standalone reproduction of the Octobox KWIC module
# -----------------------------------------------------------------------------
# Shows keyword-in-context concordance lines for a search term, and computes
# collocations (statistically notable neighbouring words).
# =============================================================================

# install.packages(c("quanteda", "quanteda.textstats", "dplyr", "readr"))
library(quanteda)
library(quanteda.textstats)
library(dplyr)
library(readr)

# ---- 1. Load and tokenise --------------------------------------------------
data <- readr::read_csv("sample_corpus.csv", show_col_types = FALSE)
corp <- quanteda::corpus(data, text_field = "text", docid_field = "doc_id")
toks <- quanteda::tokens(corp, remove_punct = TRUE)

# ---- 2. KWIC (keyword in context) -----------------------------------------
search_term <- "the"   # edit me; supports patterns e.g. phrase("sea shells")
window      <- 5L      # words of context on each side

concordance <- quanteda::kwic(toks, pattern = search_term, window = window)
print(head(concordance, 20))
readr::write_csv(as.data.frame(concordance), "kwic_results.csv")

# ---- 3. Collocations -------------------------------------------------------
# Words that co-occur more than chance would predict.
collocs <- quanteda.textstats::textstat_collocations(
  toks,
  size = 2,     # 2-word collocations
  min_count = 2 # ignore very rare pairs
)
print(head(collocs, 20))
readr::write_csv(collocs, "collocation_results.csv")

cat("\nSaved kwic_results.csv and collocation_results.csv\n")
