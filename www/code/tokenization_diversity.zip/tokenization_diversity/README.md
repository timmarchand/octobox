# Tokenization & Lexical Diversity (standalone)

Reproduces the tokenization + summary statistics behind Octobox's **Corpus
Summary**: token/type counts and lexical diversity (TTR, CTTR, MATTR).

## Run it
Open the `.Rproj`, install the listed packages, source `tokenization_diversity.R`.

## Worked example
The script tokenizes the bundled corpus and prints two diversity tables: TTR and
CTTR per document, then MATTR (a moving-average TTR that is robust to text
length). The MATTR window defaults to 25 tokens; widen or narrow it and
re-source to see the effect:

```r
mattr <- quanteda.textstats::textstat_lexdiv(toks, measure = "MATTR", MATTR_window = 50)
```

## How this differs from the Octobox app
Same measures via `quanteda.textstats::textstat_lexdiv()`. The app reports the
same TTR/CTTR/MATTR figures inside its Corpus Summary; this script isolates just
the diversity calculation so the formulas and the window parameter are easy to
inspect.

## Reading
- Covington & McFall (2010) on MATTR.
- McCarthy & Jarvis (2010) on diversity measures.
