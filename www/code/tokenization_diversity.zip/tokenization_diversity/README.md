# Tokenization & Lexical Diversity (standalone)

Reproduces the tokenization + summary statistics behind Octobox's **Corpus
Summary**: token/type counts and lexical diversity (TTR, CTTR, MATTR).

## Run it
Open the `.Rproj`, install the listed packages, source `tokenization_diversity.R`.

## Reading
- Covington & McFall (2010) on MATTR.
- McCarthy & Jarvis (2010) on diversity measures.
