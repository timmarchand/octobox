# =============================================================================
# Tokenization & Lexical Diversity - standalone reproduction
# -----------------------------------------------------------------------------
# Tokenises a corpus and reports basic counts plus lexical diversity measures
# (TTR and the more stable MATTR), mirroring the Corpus Summary / Tokenization
# parts of Octobox.
# =============================================================================

# install.packages(c("quanteda", "quanteda.textstats", "dplyr", "readr"))
library(quanteda)
library(quanteda.textstats)
library(dplyr)
library(readr)

# ---- 1. Load and tokenise --------------------------------------------------
data <- readr::read_csv("sample_corpus.csv", show_col_types = FALSE)
corp <- quanteda::corpus(data, text_field = "text", docid_field = "doc_id")
toks <- quanteda::tokens(
  corp,
  remove_punct   = TRUE,
  remove_symbols = TRUE,
  remove_numbers = FALSE
)

# ---- 2. Basic counts -------------------------------------------------------
cat("Documents:", quanteda::ndoc(toks), "\n")
cat("Total tokens:", sum(quanteda::ntoken(toks)), "\n")
cat("Total types (unique):", length(unique(unlist(quanteda::as.list(toks)))), "\n\n")

# ---- 3. Lexical diversity --------------------------------------------------
dfmat <- quanteda::dfm(toks)

# Type-Token Ratio and Moving-Average TTR (more robust to text length)
ld <- quanteda.textstats::textstat_lexdiv(
  dfmat,
  measure = c("TTR", "CTTR")
)
print(ld)

# MATTR works on the tokens object directly
mattr <- quanteda.textstats::textstat_lexdiv(toks, measure = "MATTR", MATTR_window = 25)
print(mattr)

readr::write_csv(ld, "lexical_diversity.csv")
cat("\nSaved lexical_diversity.csv\n")
