# Frequency Analysis (standalone)

A self-contained R script that reproduces the **Frequency Analysis** module of
Octobox: it counts word (or n-gram) frequencies in a corpus, optionally removing
stopwords and grouping by a metadata field.

## Run it
1. Open `frequency_analysis.Rproj` in RStudio.
2. Install the packages listed at the top of the script (run the commented
   `install.packages(...)` line once).
3. Source `frequency_analysis.R` or step through it line by line.

## Your own data
Replace `sample_corpus.csv` with your own CSV. It needs three columns:
`doc_id`, `text`, `meta`.

## Worked example
With the bundled corpus and defaults, the script prints a frequency table of
single words across the whole corpus. To get bigrams grouped by the `meta`
field instead, set three values near the top and re-source:

```r
ngram_n         <- 2L      # bigrams
remove_stopwords <- TRUE
group_by_meta   <- TRUE    # separate counts per meta value
```

## How this differs from the Octobox app
Same method, different engine. The script uses
`quanteda.textstats::textstat_frequency()`, which gives raw counts (and
docfreq) per term. The app adds a frequency-band/POS enrichment step that looks
each word up against a built-in COCA-derived reference list - so the app's table
has extra columns (band, PoS, rank) the script doesn't. The underlying counts
match; only the enrichment is app-specific.

## Things to try
- Set `ngram_n <- 2L` for bigrams.
- Toggle `remove_stopwords` and `group_by_meta`.
