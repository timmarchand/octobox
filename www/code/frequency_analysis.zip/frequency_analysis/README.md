# Frequency Analysis (standalone)

A self-contained R script that reproduces the **Frequency Analysis** module of
Octobox: it counts word (or n-gram) frequencies in a corpus, optionally removing
stopwords and grouping by a metadata field.

## Run it
1. Open `frequency_analysis.Rproj` in RStudio.
2. Install the packages listed at the top of the script (run the commented
   `install.packages(...)` line once).
3. Source `frequency_analysis.R` or step through it line by line.

## Your own data
Replace `sample_corpus.csv` with your own CSV. It needs three columns:
`doc_id`, `text`, `meta`.

## Things to try
- Set `ngram_n <- 2L` for bigrams.
- Toggle `remove_stopwords` and `group_by_meta`.
