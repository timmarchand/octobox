# =============================================================================
# Frequency Analysis - standalone reproduction of the Octobox Frequency module
# -----------------------------------------------------------------------------
# Produces a word / n-gram frequency list from a corpus, with optional
# stopword removal and grouping by metadata. This mirrors what the Frequency
# Analysis tab does, but as a plain script you can run and adapt.
# =============================================================================

# install.packages(c("quanteda", "quanteda.textstats", "dplyr", "readr"))
library(quanteda)
library(quanteda.textstats)
library(dplyr)
library(readr)

# ---- 1. Load a corpus ------------------------------------------------------
# Expects a CSV with columns: doc_id, text, meta
data <- readr::read_csv("sample_corpus.csv", show_col_types = FALSE)

corp <- quanteda::corpus(data, text_field = "text", docid_field = "doc_id")
quanteda::docvars(corp, "meta") <- data$meta

# ---- 2. Tokenise -----------------------------------------------------------
toks <- quanteda::tokens(
  corp,
  remove_punct   = TRUE,
  remove_symbols = TRUE,
  remove_numbers = FALSE
)

# ---- 3. Options (edit these) ----------------------------------------------
remove_stopwords <- TRUE   # drop common function words
ngram_n          <- 1L     # 1 = single words, 2 = bigrams, 3 = trigrams ...
group_by_meta    <- FALSE  # TRUE = separate counts per metadata category

if (remove_stopwords) {
  sw   <- quanteda::stopwords("en")
  toks <- quanteda::tokens_remove(toks, sw, case_insensitive = TRUE)
}

if (ngram_n > 1L) {
  toks <- quanteda::tokens_ngrams(toks, n = ngram_n)
}

# ---- 4. Build a document-feature matrix and count --------------------------
dfmat <- quanteda::dfm(toks)

if (group_by_meta) {
  dfmat <- quanteda::dfm_group(dfmat, groups = quanteda::docvars(toks, "meta"))
}

freq <- quanteda.textstats::textstat_frequency(dfmat)

# ---- 5. Inspect ------------------------------------------------------------
print(head(freq, 20))

# Save the full list
readr::write_csv(freq, "frequency_results.csv")
cat("\nSaved frequency_results.csv\n")
