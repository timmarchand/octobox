# Keyword Analysis (standalone)

Reproduces the **Keyword Analysis** module: keyness comparison of a target
sub-corpus against a reference sub-corpus.

## Run it
Open the `.Rproj`, install the listed packages, source `keyword_analysis.R`.

## Worked example
The script splits the corpus by the `meta` field, treats one value as the
target and the rest as the reference, and ranks words by keyness. With the
bundled data the target defaults to `"fiction"`. To compare a different group,
edit one line and re-source:

```r
target_group <- "news"     # any value present in the meta column
```

Switch the statistic via the `measure` argument of `textstat_keyness()`
(`"chi2"`, `"lr"` for log-likelihood, `"exact"`, `"pmi"`).

## How this differs from the Octobox app
Same idea, slightly different statistic surface. The script uses
`quanteda.textstats::textstat_keyness()`. The app reports keyness with a
log-likelihood / log-ratio pairing and its own effect-size column, so exact
values may differ depending on which `measure` you pick here. Conceptually they
answer the same question: which words are distinctive of the target group.

## Things to try
- Change `target_group` to another `meta` value.
- Switch `measure` between `"chi2"`, `"lr"`, `"exact"`, `"pmi"`.
