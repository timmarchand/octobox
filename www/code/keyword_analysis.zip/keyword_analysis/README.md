# Keyword Analysis (standalone)

Reproduces the **Keyword Analysis** module: keyness comparison of a target
sub-corpus against a reference sub-corpus.

## Run it
Open the `.Rproj`, install the listed packages, source `keyword_analysis.R`.

## Things to try
- Change `target_group` to another `meta` value.
- Switch `measure` between `"chi2"`, `"lr"`, `"exact"`, `"pmi"`.
