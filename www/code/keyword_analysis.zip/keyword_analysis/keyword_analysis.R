# =============================================================================
# Keyword Analysis - standalone reproduction of the Octobox Keyword module
# -----------------------------------------------------------------------------
# Compares a target sub-corpus against a reference sub-corpus to find "key"
# words - those unusually frequent in the target. Uses keyness statistics.
# =============================================================================

# install.packages(c("quanteda", "quanteda.textstats", "dplyr", "readr"))
library(quanteda)
library(quanteda.textstats)
library(dplyr)
library(readr)

# ---- 1. Load and tokenise --------------------------------------------------
data <- readr::read_csv("sample_corpus.csv", show_col_types = FALSE)
corp <- quanteda::corpus(data, text_field = "text", docid_field = "doc_id")
quanteda::docvars(corp, "meta") <- data$meta
toks <- quanteda::tokens(corp, remove_punct = TRUE)
toks <- quanteda::tokens_remove(toks, quanteda::stopwords("en"))

# ---- 2. Define target vs reference -----------------------------------------
# Here: "fiction" documents are the target, everything else is the reference.
target_group <- "fiction"
dfmat <- quanteda::dfm(toks)
is_target <- quanteda::docvars(dfmat, "meta") == target_group

# ---- 3. Keyness ------------------------------------------------------------
keyness <- quanteda.textstats::textstat_keyness(
  dfmat,
  target  = is_target,
  measure = "chi2"   # or "lr" (log-likelihood), "exact", "pmi"
)

print(head(keyness, 20))   # most "key" for the target
readr::write_csv(keyness, "keyword_results.csv")
cat("\nSaved keyword_results.csv\n")
