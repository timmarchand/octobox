# =============================================================================
# POS Tagging - standalone reproduction of the Octobox POS / Tagging modules
# -----------------------------------------------------------------------------
# Annotates each token with its part of speech (and lemma) using a udpipe
# model. The first run downloads the English model (~16 MB) into this folder.
# =============================================================================

# install.packages(c("udpipe", "dplyr", "readr"))
library(udpipe)
library(dplyr)
library(readr)

# ---- 1. Load (or download) the model ---------------------------------------
model_file <- list.files(pattern = "english.*\\.udpipe$")[1]
if (is.na(model_file)) {
  cat("Downloading English udpipe model...\n")
  dl <- udpipe::udpipe_download_model(language = "english-ewt", model_dir = ".")
  model_file <- dl$file_model
}
model <- udpipe::udpipe_load_model(model_file)

# ---- 2. Load text ----------------------------------------------------------
data <- readr::read_csv("sample_corpus.csv", show_col_types = FALSE)

# ---- 3. Annotate -----------------------------------------------------------
annotated <- udpipe::udpipe_annotate(
  model,
  x      = data$text,
  doc_id = data$doc_id
)
annotated <- as.data.frame(annotated)

# Each row is a token with columns including: token, lemma, upos (universal
# POS), xpos (treebank POS), and dependency info.
print(head(annotated[, c("doc_id", "token", "lemma", "upos", "xpos")], 25))

# ---- 4. POS distribution ---------------------------------------------------
pos_dist <- annotated %>%
  dplyr::count(upos, sort = TRUE) %>%
  dplyr::mutate(pct = round(100 * n / sum(n), 1))
print(pos_dist)

readr::write_csv(annotated, "pos_annotated.csv")
readr::write_csv(pos_dist,  "pos_distribution.csv")
cat("\nSaved pos_annotated.csv and pos_distribution.csv\n")
