# POS Tagging (standalone)

Reproduces the **Part-of-Speech** and **POS Tagging** modules using a `udpipe`
model: per-token POS tags + lemmas, and an overall POS distribution.

## Run it
Open the `.Rproj`, install the listed packages, source `pos_tagging.R`.
**First run downloads the English model (~16 MB) into this folder.**

## Worked example
On first source the script downloads `english-ewt`, annotates the bundled
corpus, prints the per-token table (token, lemma, `upos`, `xpos`), then a POS
distribution summary. Re-running reuses the downloaded model (no second
download). To tag another language, swap the model:

```r
dl <- udpipe::udpipe_download_model(language = "french-gsd", model_dir = ".")
```

## How this differs from the Octobox app
Same engine (UDPipe), same tags. The app wraps this in its tagged-token
workflow - letting you then search/concordance on `word_POS` forms - but the
tagging step itself is exactly what this script shows.

## Notes
- `upos` = Universal POS tags; `xpos` = Penn-Treebank-style tags.
- Swap in another language model via `udpipe_download_model()`.
