# POS Tagging (standalone)

Reproduces the **Part-of-Speech** and **POS Tagging** modules using a `udpipe`
model: per-token POS tags + lemmas, and an overall POS distribution.

## Run it
Open the `.Rproj`, install the listed packages, source `pos_tagging.R`.
**First run downloads the English model (~16 MB) into this folder.**

## Notes
- `upos` = Universal POS tags; `xpos` = Penn-Treebank-style tags.
- Swap in another language model via `udpipe_download_model()`.
