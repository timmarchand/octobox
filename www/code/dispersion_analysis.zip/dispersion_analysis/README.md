# Dispersion Analysis (standalone)

Reproduces the **Dispersion** module: how evenly words spread across a corpus,
via Gries' Deviation of Proportions (DP) and a range count.

## Run it
Open the `.Rproj`, install the listed packages, source `dispersion_analysis.R`.

## Worked example
The script computes DP for a single `target_word` (default `"the"`), then prints
a small comparison table for several words (`the`, `dog`, `she`, `fox`, `sea`).
DP runs from 0 (perfectly even across the corpus parts) to ~1 (very clumped in a
few parts). To test your own word, edit one line and re-source:

```r
target_word <- "dog"
```

## How this differs from the Octobox app
Same DP formula (the `calculate_dp()` here is the app's, lifted out), but the
script matches a **single token**: `sum(p == target_word)`. The app additionally
supports **multi-word phrases** (e.g. searching `thank you` matches the bigram as
a sequence) and tagged/regex search. To check a phrase in the script you would
need to extend the match from a single `==` to a consecutive-token search; the
single-word case shown here is the core method.

## Reading
- Gries, S. Th. (2008). Dispersions and adjusted frequencies in corpora.
  *International Journal of Corpus Linguistics*, 13(4), 403-437.
- Gries, S. Th. (2020). Analyzing dispersion. In Paquot & Gries (Eds.),
  *A Practical Handbook of Corpus Linguistics* (pp. 99-118). Springer.
