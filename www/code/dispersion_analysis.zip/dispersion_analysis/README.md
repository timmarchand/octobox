# Dispersion Analysis (standalone)

Reproduces the **Dispersion** module: how evenly words spread across a corpus,
via Gries' Deviation of Proportions (DP) and a range count.

## Run it
Open the `.Rproj`, install the listed packages, source `dispersion_analysis.R`.

## Reading
- Gries, S. Th. (2008). Dispersions and adjusted frequencies in corpora.
  *International Journal of Corpus Linguistics*, 13(4), 403-437.
