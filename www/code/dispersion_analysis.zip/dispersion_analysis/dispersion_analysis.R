# =============================================================================
# Dispersion Analysis - standalone reproduction of the Octobox Dispersion module
# -----------------------------------------------------------------------------
# Measures how evenly a word is spread across the parts of a corpus, rather
# than just how often it occurs. Implements Gries' Deviation of Proportions
# (DP) and a simple range count.
# =============================================================================

# install.packages(c("quanteda", "dplyr", "readr"))
library(quanteda)
library(dplyr)
library(readr)

# ---- 1. Load and tokenise --------------------------------------------------
data <- readr::read_csv("sample_corpus.csv", show_col_types = FALSE)
corp <- quanteda::corpus(data, text_field = "text", docid_field = "doc_id")
toks <- quanteda::tokens(corp, remove_punct = TRUE)
toks <- quanteda::tokens_tolower(toks)

# ---- 2. Deviation of Proportions (Gries 2008) ------------------------------
# DP ranges 0 (perfectly even) to ~1 (very clumped).
calculate_dp <- function(frequencies, corpus_sizes) {
  if (sum(frequencies) == 0) return(NA_real_)
  expected <- corpus_sizes / sum(corpus_sizes)
  observed <- frequencies / sum(frequencies)
  sum(abs(expected - observed)) / 2
}

# corpus sizes = tokens per document
parts        <- quanteda::as.list(toks)
corpus_sizes <- lengths(parts)

# ---- 3. Compute dispersion for a chosen word -------------------------------
target_word <- "the"   # edit me

freqs <- vapply(parts, function(p) sum(p == target_word), numeric(1))

dp    <- calculate_dp(freqs, corpus_sizes)
range <- sum(freqs > 0)   # number of documents containing the word

cat(sprintf("Word: %s\n", target_word))
cat(sprintf("Total frequency: %d\n", sum(freqs)))
cat(sprintf("Range (docs containing it): %d of %d\n", range, length(parts)))
cat(sprintf("Deviation of Proportions (DP): %.3f\n", dp))

# ---- 4. Do it for several words at once ------------------------------------
words <- c("the", "dog", "she", "fox", "sea")
result <- data.frame(
  word  = words,
  freq  = sapply(words, function(w) sum(vapply(parts, function(p) sum(p == w), numeric(1)))),
  range = sapply(words, function(w) sum(vapply(parts, function(p) sum(p == w), numeric(1)) > 0)),
  DP    = sapply(words, function(w) calculate_dp(vapply(parts, function(p) sum(p == w), numeric(1)), corpus_sizes))
)
print(result)
readr::write_csv(result, "dispersion_results.csv")
cat("\nSaved dispersion_results.csv\n")
